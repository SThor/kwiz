/**
 * Created by jgarcia on 01/12/2017.
 */

var fs = require('fs');
var favicon = require('serve-favicon');
var path = require('path');
var express = require('express');
var app = express();

//load questions file
var quiz = require('./data/bluffer.json');

//make the server and the socketsio
var server = require('http').createServer(app);
var io = require('socket.io')(server);

//data variables
var players = {};       //logged-in players
var clientCount = 0;    //all sockets counter
var answers = {};       //counters for each option of each question

//communication protocol variables
const EVENT_CLIENT_COUNT = "client_count";
const EVENT_PLAYERS = "players";
const EVENT_LOGGED_IN = "logged_in";
const EVENT_ANSWER = "answer";
const EVENT_UPDATE_ANSWERS = "update_answers";

//server static file in the public directory
app.use(express.static('public'))
    .use(favicon(path.join(__dirname, 'public', 'favicon.ico')));

// client connexion
io.on('connection', function (socket) {
    clientCount++;
    io.emit(EVENT_CLIENT_COUNT,{'count':clientCount});

    socket.emit(EVENT_PLAYERS,{players:players});

    console.log("new client #"+clientCount);

    socket.on('disconnect', function () {
        clientCount--;
        io.emit(EVENT_CLIENT_COUNT,{'count':clientCount});
        console.log("clients left : "+clientCount);

        delete players[socket.id];
        io.emit(EVENT_PLAYERS,{players:players});
    });

    socket.on(EVENT_LOGGED_IN, (data) => {
        console.log(data);
        loggedIn(data,socket);
    });
});

function answered(data, socket) {
    oldCounter = answers[data.qID][data.option];
    if(oldCounter){
        answers[data.qID][data.option] = 1;
    }else{
        answers[data.qID][data.option]++;
    }

    io.emit(EVENT_UPDATE_ANSWERS,{answers:answers});
}

function loggedIn(data,socket){
    console.log("login de "+data["nickname"]);

    players[socket.id] = {id:socket.id,nickname:data['nickname'],score:0};

    io.emit(EVENT_PLAYERS,{players:players});

    //socket.on(EVENT_ANSWER, answered(data,socket));

    //send the questions to the client
    socket.emit("quiz", quiz);
}

server.listen(8080,"0.0.0.0");