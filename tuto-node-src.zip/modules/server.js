/**
 * Created by jeremiegarcia on 01/12/2017.
 */
var monmodule = require('./module-test');

monmodule.direBonjour();
monmodule.direByeBye();