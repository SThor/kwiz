/**
 * Created by jgarcia on 01/12/2017.
 */

var fs = require('fs');
var favicon = require('serve-favicon');
var path = require('path');
var express = require('express');
var app = express();

//load questions file
var quiz = require('./data/bluffer.json');

//make the server and the socketsio
var server = require('http').createServer(app);
var io = require('socket.io')(server);

//server static file in the public directory
app.use(express.static('public'))
    .use(favicon(path.join(__dirname, 'public', 'favicon.ico')));

// client connexion
io.on('connection', function (socket) {

    //send the questions to the client
    socket.emit("quiz", quiz);
});

server.listen(8080);